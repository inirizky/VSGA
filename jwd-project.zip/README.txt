#DISINI CUY - Website Pariwisata

Berikut adalah cara untuk menginstall aplikasi DISINI CUY:
1. Masuk ke dalam PHPMyAdmin, buat database baru dengan nama `pariwisata`
2. Import pariwisata.sql yang terletak pada folder database.
3. Ekstrak file "jwd-project.zip" ke dalam folder "xampp/htdocs".
4. Sesuaikan koneksi database anda dengan cara pergi ke file "service/db.php".
5. Ganti nilai dari variable host, username, password, dan db dengan config XAMPP anda.
6. Nyalakan service Apache beserta MySQL pada XAMPP.
7. Pergi ke browser dan ketikan localhost/jwd-project.